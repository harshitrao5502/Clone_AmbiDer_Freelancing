from fastapi import APIRouter, HTTPException
from database import supabase

router = APIRouter()

# GET all reviews for a listing
@router.get("/{listing_id}")
def get_reviews(listing_id: str):
    result = supabase.table("reviews")\
        .select("*")\
        .eq("listing_id", listing_id)\
        .execute()
    return result.data

# POST create new review
@router.post("/")
def create_review(review: dict):
    result = supabase.table("reviews")\
        .insert(review)\
        .execute()
    return result.data