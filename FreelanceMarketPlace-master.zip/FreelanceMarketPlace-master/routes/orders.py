from fastapi import APIRouter, HTTPException
from database import supabase

router = APIRouter()

# GET all orders of a buyer
@router.get("/{buyer_id}")
def get_orders(buyer_id: str):
    result = supabase.table("orders")\
        .select("*")\
        .eq("buyer_id", buyer_id)\
        .execute()
    return result.data

# POST create new order
@router.post("/")
def create_order(order: dict):
    result = supabase.table("orders")\
        .insert(order)\
        .execute()
    return result.data

# PUT update order status
@router.put("/{order_id}")
def update_order(order_id: str, update: dict):
    result = supabase.table("orders")\
        .update(update)\
        .eq("id", order_id)\
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Order not found")
    return result.data