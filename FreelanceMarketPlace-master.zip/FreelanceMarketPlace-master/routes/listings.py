from fastapi import APIRouter, HTTPException
from database import supabase

router = APIRouter()

# GET all listings
@router.get("/")
def get_all_listings():
    result = supabase.table("listings").select("*").execute()
    return result.data

# GET listing by ID
@router.get("/{listing_id}")
def get_listing(listing_id: str):
    result = supabase.table("listings")\
        .select("*")\
        .eq("id", listing_id)\
        .execute()
    if not result.data:
        raise HTTPException(status_code=404, detail="Listing not found")
    return result.data[0]

# GET listings by type (product or service)
@router.get("/type/{listing_type}")
def get_by_type(listing_type: str):
    result = supabase.table("listings")\
        .select("*")\
        .eq("listing_type", listing_type)\
        .execute()
    return result.data

# POST create new listing
@router.post("/")
def create_listing(listing: dict):
    result = supabase.table("listings").insert(listing).execute()
    return result.data