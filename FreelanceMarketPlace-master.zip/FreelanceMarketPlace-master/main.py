from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import listings, orders, reviews, messages

app = FastAPI(title="Marketplace API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(
    listings.router,
    prefix="/listings",
    tags=["Listings"]
)

app.include_router(
    orders.router,
    prefix="/orders",
    tags=["Orders"]
)

app.include_router(
    reviews.router,
    prefix="/reviews",
    tags=["Reviews"]
)

app.include_router(
    messages.router,
    prefix="/messages",
    tags=["Messages"]
)

@app.get("/")
def root():
    return {"message": "Marketplace API is running!"}